(() => {
  globalThis.DCE = globalThis.DCE || {};
})();
