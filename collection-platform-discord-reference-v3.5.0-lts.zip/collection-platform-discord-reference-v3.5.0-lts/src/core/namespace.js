(() => {
  globalThis.DCE = globalThis.DCE || {};
})();
